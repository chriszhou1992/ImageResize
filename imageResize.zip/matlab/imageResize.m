%% read file
f1 = 'wave.png';
f2 = 'bubble.jpg';
f3 = 'lake_small.jpg';
I = im2double(imread(f3));

%% gradient
% method = 'sobel';
% 
% [Gx(:,:,1), Gy(:,:,1)] = imgradientxy(I(:,:,1), method);
% [Gx(:,:,2), Gy(:,:,2)] = imgradientxy(I(:,:,2), method);
% [Gx(:,:,3), Gy(:,:,3)] = imgradientxy(I(:,:,3), method);
% 
% Gx = sqrt(Gx(:,:,1).^2+Gx(:,:,2).^2+Gx(:,:,3).^2);
% Gy = sqrt(Gy(:,:,1).^2+Gy(:,:,2).^2+Gy(:,:,3).^2);
% G = Gx + Gy;

%% resize
figure();
% tic
% for i = 1:100
%     I = carveHorizontal(I);
% end
% toc
% tic
% for i = 1:100
%     I = carveVertical(I);
% end
% toc

I = kInsertVertical(I, 100);
imshow(I);
